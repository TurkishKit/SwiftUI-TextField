//
//  SwiftUITextFieldApp.swift
//  SwiftUITextField
//
//  Created by Ufuk Köşker on 18.09.2020.
//

import SwiftUI

@main
struct SwiftUITextFieldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
