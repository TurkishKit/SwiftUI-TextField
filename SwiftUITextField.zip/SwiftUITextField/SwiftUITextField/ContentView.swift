//
//  ContentView.swift
//  SwiftUITextField
//
//  Created by Ufuk Köşker on 18.09.2020.
//

import SwiftUI

struct ContentView: View {
    @State var text: String = ""
    @State var sifre: String = ""
    var body: some View {
        
        VStack {
            Text(text)
            TextField("Placeholder", text: $text)
                .textContentType(.password)
                .keyboardType(.numberPad)
                .padding()
                .background(Color.black.opacity(0.1))
                .cornerRadius(15)
                .padding()
            
            SecureField("Şifre", text: $sifre)
                .padding()
                .background(Color.black.opacity(0.1))
                .cornerRadius(15)
                .padding()

        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
